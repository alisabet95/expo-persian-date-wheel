# expo-persian-date-wheel

A beautiful, customizable Persian/Jalali date wheel picker for Expo and React Native with multiple elegant themes inspired by family names.

## Features

- 🎨 **4 Beautiful Themes**: Atlas, Adeleh, Shadi, and Esi (with dark/light modes)
- 📅 **Persian/Jalali Calendar** support
- ⏰ **Optional time selection** (hour & minute)
- 🎡 **Smooth wheel-style picker** with auto-scroll
- 🌍 **RTL/LTR support** (Persian & English)
- 🎯 **Customizable year ranges**
- 💅 **Fully typed** TypeScript support

## Installation

```bash
npm install expo-persian-date-wheel moment-jalaali
```
